# better-canvas
chromium extension that enchances the canvas experience
