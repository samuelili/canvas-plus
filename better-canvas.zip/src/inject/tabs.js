async function initialTabs({courses, enabled}) {
  if (!enabled) {
    // add settings button to the side then
    settingsButton();
    return;
  }
  document.body.classList.add('tabs-enabled');
  let topBarCourses = document.createElement("div");
  topBarCourses.id = "tabs-courses";

  // need to shift page down if in conversations
  if (window.location.pathname.split('/')[1].startsWith('conversations'))
    document.getElementById('main').style.top = '50px';

  document.getElementById("wrapper").prepend(topBarCourses);

  function addElements(courses) {
    sessionStorage.setItem('courses', JSON.stringify(courses));

    for (let course of courses) {
      console.log('Adding tab', course);
      let courseElement = document.createElement("a");
      courseElement.classList.add('tabs-course');
      if (window.location.pathname.split('/')[2] === course.id)
        courseElement.classList.add('selected');

      courseElement.href = "/courses/" + course.id;
      courseElement.innerText = course.name;

      topBarCourses.append(courseElement);
    }

    /*
    Need to inject the hamburger dropdown
     */
    let $dropdown = $(`<div class="tabs-dropdown">
            <a href="https://cuhsd.instructure.com/courses">All Courses</a>
            <a href="#" class="settings">Settings</a>
        </div>`);
    let $dropdownButton = $(`<div class="tabs-course tabs-dropdown-button">☰</div>`);

    $dropdownButton.on('click', () => {
      $dropdown.toggleClass('active');
    });

    $dropdown.find('.settings').on('click', () =>
      chrome.runtime.sendMessage({action: "OPTIONS"}));

    $dropdown.click(() => $dropdown.removeClass('active'));

    topBarCourses.append($dropdownButton[0]);
    topBarCourses.append($dropdown[0]);
  }

  if (sessionStorage.getItem('courses') === null) {
    let courses = await fetch('/api/v1/users/self/favorites/courses?include[]=term&exclude[]=enrollment', {
      headers: CANVAS_HEADERS
    });
    courses = await courses.json();

    // update chrome storage
    chrome.runtime.sendMessage({
      action: "SET_COURSES",
      courses,
      instance: INSTANCE
    })
    addElements(courses);
  } else {
    addElements(courses);
  }
}

chrome.runtime.sendMessage({
  action: 'GET_TABS',
  instance: INSTANCE
}, settings => {
  if (settings) initialTabs(settings);
});